// Opportunity Passport v0.5.0 — onboarding and alerts upgrade
package com.opportunitypassport.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Purple = androidx.compose.ui.graphics.Color(0xFF5B2CFF)
private val Ink = androidx.compose.ui.graphics.Color(0xFF171426)
private val Muted = androidx.compose.ui.graphics.Color(0xFF6F6A7D)
private val Bg = androidx.compose.ui.graphics.Color(0xFFF7F5FC)

data class Opportunity(val id:String,val title:String,val type:String,val country:String,val field:String,val level:String,val funding:String,val fee:String,val deadline:String,val verified:Boolean,val url:String,val requirements:List<String>)

private val opportunities = listOf(
 Opportunity("jp-nursing","Nursing Degree Scholarship","Scholarship","Japan 🇯🇵","Nursing","Undergraduate","Fully funded","Free","14 Oct",true,"https://www.studyinjapan.go.jp/en/",listOf("Secondary-school qualification","Check nationality rules","Meet the stated deadline")),
 Opportunity("ca-scholarship","International Student Scholarship","Scholarship","Canada 🇨🇦","Multiple fields","Undergraduate","Tuition support","Free","30 Nov",true,"https://www.educanada.ca/scholarships-bourses/index.aspx?lang=eng",listOf("Secondary-school qualification","International student eligibility","Program-specific requirements")),
 Opportunity("va-job","Beginner Virtual Assistant Opportunity","Job","Worldwide 🌍","Virtual Assistance","Any","Paid","Free","Rolling",true,"https://www.upwork.com/",listOf("Basic communication skills","Reliable internet","Profile matching the role")),
 Opportunity("skills-course","Free Digital Skills Course","Course","Online 🌐","Digital skills","Any","Free course","Free","Rolling",true,"https://grow.google/intl/ssa-en/",listOf("Internet access","Create an account if required","Complete course activities")),
 Opportunity("innovation","Global Student Innovation Challenge","Competition","Worldwide 🌍","Innovation","Student","Prizes","Free","20 Dec",true,"https://www.globalstudentchallenge.com/",listOf("Student eligibility","Original project/idea","Submit before deadline"))
)

data class UserProfile(val name:String="",val country:String="Nigeria",val level:String="Undergraduate",val field:String="Nursing",val freeOnly:Boolean=true,val alerts:Boolean=true)

class MainActivity:ComponentActivity(){ override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{OpportunityPassportApp()}} }

@Composable fun OpportunityPassportApp(){
 val context=LocalContext.current; val prefs=context.getSharedPreferences("opportunity_passport",Context.MODE_PRIVATE)
 var tab by remember{mutableIntStateOf(0)}; var selected by remember{mutableStateOf<Opportunity?>(null)}; var onboardingDone by remember{mutableStateOf(prefs.getBoolean("onboardingDone",false))}
 var profile by remember{mutableStateOf(UserProfile(prefs.getString("name","")?:"",prefs.getString("country","Nigeria")?:"Nigeria", "Undergraduate",prefs.getString("field","Nursing")?:"Nursing",prefs.getBoolean("freeOnly",true),prefs.getBoolean("alerts",true)))}
 var savedIds by remember{mutableStateOf(prefs.getStringSet("saved",emptySet())?.toSet()?:emptySet())}
 fun saveState(){prefs.edit().putString("name",profile.name).putString("country",profile.country).putString("field",profile.field).putBoolean("freeOnly",profile.freeOnly).putBoolean("alerts",profile.alerts).putStringSet("saved",savedIds).apply()}
 MaterialTheme(colorScheme=lightColorScheme(primary=Purple,background=Bg,surface=androidx.compose.ui.graphics.Color.White)){if(!onboardingDone){OnboardingScreen({onboardingDone=true;prefs.edit().putBoolean("onboardingDone",true).apply()})}else{
  Scaffold(containerColor=Bg,bottomBar={NavigationBar{val nav=listOf("Home" to Icons.Default.Home,"Discover" to Icons.Default.Search,"Saved" to Icons.Default.Bookmark,"Alerts" to Icons.Default.Notifications,"Profile" to Icons.Default.Person);nav.forEachIndexed{i,p->NavigationBarItem(tab==i,{tab=i},icon={Icon(p.second,null)},label={Text(p.first)})}}}){padding->Box(Modifier.padding(padding).fillMaxSize()){when(tab){0->HomeScreen(profile,savedIds,{selected=it},{tab=1});1->DiscoverScreen(profile,savedIds,{selected=it});2->SavedScreen(profile,savedIds,{selected=it});3->AlertsScreen(profile,savedIds,{selected=it});else->ProfileScreen(profile){profile=it;saveState()}}}}
  }selected?.let{item->OpportunityDialog(item,matchScore(item,profile),savedIds.contains(item.id),{savedIds=if(savedIds.contains(item.id))savedIds-item.id else savedIds+item.id;saveState()},{selected=null})}
 }
}

fun matchScore(i:Opportunity,p:UserProfile):Int{var s=50;if(i.level.equals(p.level,true)||i.level=="Any"||i.level=="Student")s+=18;if(i.field.equals(p.field,true)||i.field=="Multiple fields"||i.field=="Digital skills")s+=18;if(p.freeOnly&&i.fee.equals("Free",true))s+=10;if(i.verified)s+=4;return s.coerceIn(0,100)}

@Composable fun Header(title:String,subtitle:String?=null){Column(Modifier.padding(horizontal=20.dp,vertical=18.dp)){Text(title,fontSize=28.sp,fontWeight=FontWeight.Bold,color=Ink);subtitle?.let{Spacer(Modifier.height(4.dp));Text(it,color=Muted,fontSize=14.sp)}}}

@Composable fun HomeScreen(profile:UserProfile,saved:Set<String>,open:(Opportunity)->Unit,discover:()->Unit){Column{Header(if(profile.name.isBlank())"Opportunity Passport" else "Hi, ${profile.name} 👋","Your dreams. Our mission. ✈️");Card(Modifier.padding(horizontal=16.dp).fillMaxWidth(),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Purple)){Column(Modifier.padding(20.dp)){Text("Find opportunities that fit you.",color=androidx.compose.ui.graphics.Color.White,fontSize=20.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(7.dp));Text("Personalized matches for scholarships, jobs, courses and competitions.",color=androidx.compose.ui.graphics.Color.White.copy(alpha=.9f));Spacer(Modifier.height(14.dp));Button(onClick=discover,colors=ButtonDefaults.buttonColors(containerColor=androidx.compose.ui.graphics.Color.White)){Text("Explore opportunities",color=Purple)}}};Spacer(Modifier.height(18.dp));Text("Best matches for you",Modifier.padding(horizontal=20.dp),fontWeight=FontWeight.Bold,fontSize=19.sp);LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){items(opportunities.sortedByDescending{matchScore(it,profile)}.take(4)){OpportunityCard(it,matchScore(it,profile),saved.contains(it.id),open)}}}}

@Composable fun DiscoverScreen(profile:UserProfile,saved:Set<String>,open:(Opportunity)->Unit){var q by remember{mutableStateOf("")};var type by remember{mutableStateOf("All")};var free by remember{mutableStateOf(false)};val types=listOf("All","Scholarship","Job","Course","Competition");val filtered=opportunities.filter{i->val x=q.trim().lowercase(Locale.getDefault());(x.isBlank()||"${i.title} ${i.field} ${i.country} ${i.type}".lowercase(Locale.getDefault()).contains(x))&&(type=="All"||i.type==type)&&(!free||i.fee=="Free")};Column{Header("Discover","Search and filter opportunities");OutlinedTextField(q,{q=it},Modifier.fillMaxWidth().padding(horizontal=16.dp),singleLine=true,leadingIcon={Icon(Icons.Default.Search,null)},placeholder={Text("Search scholarships, jobs...")},shape=RoundedCornerShape(16.dp));Row(Modifier.padding(16.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)){types.forEach{FilterChip(type==it,{type=it},label={Text(it)})}};Row(Modifier.padding(horizontal=16.dp),verticalAlignment=Alignment.CenterVertically){FilterChip(free,{free=!free},label={Text("No application fee")})};Text("${filtered.size} opportunities",Modifier.padding(20.dp,8.dp),color=Muted);LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){items(filtered){OpportunityCard(it,matchScore(it,profile),saved.contains(it.id),open)}}}}

@Composable fun SavedScreen(profile:UserProfile,saved:Set<String>,open:(Opportunity)->Unit){val list=opportunities.filter{saved.contains(it.id)};Column{Header("Saved","Your shortlist");if(list.isEmpty())Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.BookmarkBorder,null,tint=Purple,modifier=Modifier.size(54.dp));Text("Nothing saved yet",fontWeight=FontWeight.Bold,fontSize=19.sp);Text("Bookmark an opportunity to keep it here.",color=Muted)}}else LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){items(list){OpportunityCard(it,matchScore(it,profile),true,open)}}}}

@Composable fun ProfileScreen(p:UserProfile,onSave:(UserProfile)->Unit){var name by remember(p){mutableStateOf(p.name)};var country by remember(p){mutableStateOf(p.country)};var field by remember(p){mutableStateOf(p.field)};var free by remember(p){mutableStateOf(p.freeOnly)};var alerts by remember(p){mutableStateOf(p.alerts)};Column{Header("Profile","Personalize your matches");Card(Modifier.padding(16.dp).fillMaxWidth(),shape=RoundedCornerShape(20.dp)){Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(11.dp)){OutlinedTextField(name,{name=it},label={Text("Name")},modifier=Modifier.fillMaxWidth(),singleLine=true);OutlinedTextField(country,{country=it},label={Text("Country")},modifier=Modifier.fillMaxWidth(),singleLine=true);OutlinedTextField(field,{field=it},label={Text("Career / field")},modifier=Modifier.fillMaxWidth(),singleLine=true);Text("Education: Undergraduate",color=Muted);Row(verticalAlignment=Alignment.CenterVertically){Checkbox(free,{free=it});Text("Prioritize no-fee opportunities")};Row(verticalAlignment=Alignment.CenterVertically){Checkbox(alerts,{alerts=it});Text("Deadline & new-match alerts")};Button(onClick={onSave(UserProfile(name,country,"Undergraduate",field,free,alerts))},Modifier.fillMaxWidth()){Text("Save preferences")}}};Card(Modifier.padding(horizontal=16.dp).fillMaxWidth(),shape=RoundedCornerShape(20.dp)){Column(Modifier.padding(20.dp)){Text("Safety & trust",fontWeight=FontWeight.Bold,fontSize=18.sp);Spacer(Modifier.height(6.dp));Text("We show verification status and direct sources. Never pay a person to unlock a scholarship.",color=Muted)}}}}


@Composable fun OnboardingScreen(done:()->Unit){
 Surface(Modifier.fillMaxSize(),color=Bg){
  Column(Modifier.fillMaxSize().padding(28.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally){
   Text("🌍✈️",fontSize=54.sp)
   Spacer(Modifier.height(18.dp))
   Text("Opportunity Passport",fontSize=30.sp,fontWeight=FontWeight.Bold,color=Ink)
   Spacer(Modifier.height(8.dp))
   Text("Your dreams. Our mission.",fontSize=17.sp,color=Purple,fontWeight=FontWeight.SemiBold)
   Spacer(Modifier.height(18.dp))
   Text("Find scholarships, jobs, courses and competitions that fit your goals — with match scores and direct official sources.",fontSize=15.sp,color=Muted)
   Spacer(Modifier.height(26.dp))
   Button(onClick=done,Modifier.fillMaxWidth().height(52.dp),shape=RoundedCornerShape(16.dp)){Text("Get started",fontSize=16.sp)}
   Spacer(Modifier.height(10.dp))
   Text("Tip: never pay someone just to access a scholarship.",fontSize=12.sp,color=Muted)
  }
 }
}

@Composable fun AlertsScreen(profile:UserProfile,saved:Set<String>,open:(Opportunity)->Unit){
 val matches=opportunities.filter{matchScore(it,profile)>=75}.sortedByDescending{matchScore(it,profile)}
 Column{
  Header("Alerts","Deadlines and strong matches")
  if(!profile.alerts){
   Card(Modifier.padding(16.dp).fillMaxWidth(),shape=RoundedCornerShape(18.dp)){
    Column(Modifier.padding(18.dp)){Text("Alerts are off",fontWeight=FontWeight.Bold,fontSize=18.sp);Spacer(Modifier.height(6.dp));Text("Turn on “Deadline & new-match alerts” in Profile to keep this section active.",color=Muted)}
   }
  }else{
   Card(Modifier.padding(horizontal=16.dp).fillMaxWidth(),shape=RoundedCornerShape(18.dp)){
    Column(Modifier.padding(18.dp)){Text("Your alert feed",fontWeight=FontWeight.Bold,fontSize=18.sp);Spacer(Modifier.height(5.dp));Text("${matches.size} strong matches based on your current profile.",color=Muted)}
   }
   LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
    items(matches){OpportunityCard(it,matchScore(it,profile),saved.contains(it.id),open)}
   }
  }
 }
}

@Composable fun OpportunityCard(i:Opportunity,score:Int,saved:Boolean,open:(Opportunity)->Unit){Card(Modifier.fillMaxWidth().clickable{open(i)},shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(16.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text(i.title,Modifier.weight(1f),fontWeight=FontWeight.Bold,fontSize=17.sp,maxLines=2,overflow=TextOverflow.Ellipsis);if(i.verified)Icon(Icons.Default.Verified,"Verified",tint=Purple)};Text("${i.type} • ${i.country}",color=Muted);Spacer(Modifier.height(7.dp));Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){AssistChip(onClick={},label={Text(i.funding)});AssistChip(onClick={},label={Text("Fee: ${i.fee}")})};Spacer(Modifier.height(7.dp));Row(verticalAlignment=Alignment.CenterVertically){Text("$score% match",color=Purple,fontWeight=FontWeight.Bold);Spacer(Modifier.weight(1f));Text("Deadline: ${i.deadline}",fontSize=12.sp,fontWeight=FontWeight.SemiBold);if(saved){Spacer(Modifier.width(6.dp));Icon(Icons.Default.Bookmark,null,tint=Purple)}}}}}

@Composable fun OpportunityDialog(i:Opportunity,score:Int,saved:Boolean,toggle:()->Unit,dismiss:()->Unit){val context=LocalContext.current;AlertDialog(onDismissRequest=dismiss,title={Text(i.title)},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){Text("🎯 $score% match",fontWeight=FontWeight.Bold,color=Purple);Text("${i.type} • ${i.country}");Text("Field: ${i.field}");Text("Level: ${i.level}");Text("Funding: ${i.funding}");Text("Application fee: ${i.fee}");Text("Deadline: ${i.deadline}");Text(if(i.verified)"✓ Verified source":"Verification pending");Text("Requirements",fontWeight=FontWeight.Bold);i.requirements.forEach{Text("• $it")}}},confirmButton={Button(onClick={context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(i.url)))}){Text("Apply / Official site")}},dismissButton={TextButton(onClick=toggle){Text(if(saved)"Unsave" else "Save")}})}
